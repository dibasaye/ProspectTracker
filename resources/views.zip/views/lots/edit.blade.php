<x-app-layout>
    <x-slot name="header">
        <h2 class="h4 fw-bold">
            <i class="fas fa-edit me-2"></i>Modifier le Lot - {{ $lot->lot_number }} - {{ $site->name }}
        </h2>
    </x-slot>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <form action="{{ route('sites.lots.update', ['site' => $site->id, 'lot' => $lot->id]) }}" method="POST">
                        @csrf
                        @method('PUT')

                        <!-- Numéro du lot -->
                        <div class="mb-3">
                            <label for="lot_number" class="form-label">Numéro du lot</label>
                            <input type="text" name="lot_number" id="lot_number" class="form-control" 
                                   value="{{ old('lot_number', $lot->lot_number) }}" required>
                            @error('lot_number')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>

                        <!-- Superficie -->
                        <div class="mb-3">
                            <label for="area" class="form-label">Superficie </label>
                            <input type="number" step="0.01" name="area" id="area" class="form-control" 
                                   value="{{ old('area', $lot->area) }}" required>
                            @error('area')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>

                        <!-- Position -->
                        <div class="mb-3">
                            <label for="position" class="form-label">Position</label>
                            <select name="position" id="position" class="form-select" required>
                                <option value="">-- Choisir --</option>
                                <option value="interieur" {{ (old('position', $lot->position) == 'interieur') ? 'selected' : '' }}>Intérieur</option>
                                <option value="facade" {{ (old('position', $lot->position) == 'facade') ? 'selected' : '' }}>Façade (+10%)</option>
                                <option value="angle" {{ (old('position', $lot->position) == 'angle') ? 'selected' : '' }}>Angle (+10%)</option>
                            </select>
                            @error('position')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>

                        <!-- Prix de base -->
                        <div class="mb-3">
                            <label for="base_price" class="form-label">Prix de base (FCFA)</label>
                            <input type="number" step="0.01" name="base_price" id="base_price" class="form-control" 
                                   value="{{ old('base_price', $lot->base_price) }}" required>
                            @error('base_price')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                            <small class="text-muted">Ce prix sera automatiquement ajusté selon la position (angle/façade)</small>
                        </div>

                        <!-- Prix pour paiement 1 an -->
                        <div class="mb-3">
                            <label for="one_year_price" class="form-label">Prix pour paiement 1 an (FCFA)</label>
                            <input type="number" step="0.01" name="one_year_price" id="one_year_price" class="form-control" 
                                   value="{{ old('one_year_price', $lot->one_year_price) }}" required>
                            @error('one_year_price')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>

                        <!-- Prix pour paiement 2 ans -->
                        <div class="mb-3">
                            <label for="two_years_price" class="form-label">Prix pour paiement 2 ans (FCFA)</label>
                            <input type="number" step="0.01" name="two_years_price" id="two_years_price" class="form-control" 
                                   value="{{ old('two_years_price', $lot->two_years_price) }}" required>
                            @error('two_years_price')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>

                        <!-- Prix pour paiement 3 ans -->
                        <div class="mb-3">
                            <label for="three_years_price" class="form-label">Prix pour paiement 3 ans (FCFA)</label>
                            <input type="number" step="0.01" name="three_years_price" id="three_years_price" class="form-control" 
                                   value="{{ old('three_years_price', $lot->three_years_price) }}" required>
                            @error('three_years_price')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>

                        <!-- Statut -->
                        <div class="mb-3">
                            <label for="status" class="form-label">Statut du lot</label>
                            <select name="status" id="status" class="form-select" required>
                                <option value="disponible" {{ (old('status', $lot->status) == 'disponible') ? 'selected' : '' }}>Disponible</option>
                                <option value="reserve_temporaire" {{ (old('status', $lot->status) == 'reserve_temporaire') ? 'selected' : '' }}>Réservation temporaire</option>
                                <option value="reserve" {{ (old('status', $lot->status) == 'reserve') ? 'selected' : '' }}>Réservé</option>
                                <option value="vendu" {{ (old('status', $lot->status) == 'vendu') ? 'selected' : '' }}>Vendu</option>
                            </select>
                            @error('status')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>

                        <!-- Description -->
                        <div class="mb-3">
                            <label for="description" class="form-label">Description (optionnelle)</label>
                            <textarea name="description" id="description" rows="3" class="form-control">{{ old('description', $lot->description) }}</textarea>
                        </div>

                        <div class="d-flex justify-content-end">
                            <a href="{{ route('sites.lots', $site) }}" class="btn btn-secondary me-2">Annuler</a>
                            <button type="submit" class="btn btn-primary">Mettre à jour le lot</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    @push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const positionSelect = document.getElementById('position');
            const basePriceInput = document.getElementById('base_price');
            
            // Prix par défaut pour chaque position
            const prices = {
                'interieur': {{ $site->interior_price }},
                'facade': {{ $site->facade_price }},
                'angle': {{ $site->angle_price }}
            };

            // Mettre à jour le prix quand la position change
            positionSelect.addEventListener('change', function() {
                const selectedPosition = this.value;
                if (prices[selectedPosition]) {
                    basePriceInput.value = prices[selectedPosition];
                }
            });

            // Initialiser le prix à la position actuelle
            if (positionSelect.value && prices[positionSelect.value]) {
                basePriceInput.value = prices[positionSelect.value];
            }
        });
    </script>
    @endpush
</x-app-layout>
