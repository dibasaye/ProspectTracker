<x-app-layout>
    <x-slot name="header">
        <h2 class="h4 fw-bold">
            <i class="fas fa-plus me-2"></i>Ajout manuel de lots - {{ $site->name }}
        </h2>
    </x-slot>

    <div class="container py-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <form action="{{ route('sites.lots.store-multiple', $site) }}" method="POST" id="addLotsForm">
                    @csrf
                    
                    <div class="mb-4">
                        <h5 class="mb-3">Options de base</h5>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Position par défaut</label>
                                <select name="default_position" id="defaultPosition" class="form-select">
                                    <option value="interieur">Intérieur</option>
                                    <option value="facade">Façade (+10%)</option>
                                    <option value="angle">Angle (+10%)</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Superficie par défaut (m²)</label>
                                <input type="number" step="0.01" class="form-control" id="defaultArea" value="{{ $site->total_area }}">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Prix au m² (FCFA)</label>
                                <input type="number" step="0.01" class="form-control" id="pricePerSqm" value="{{ $site->price_per_sqm ?? 0 }}">
                            </div>
                        </div>
                    </div>

                    <div class="mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0">Liste des lots à ajouter</h5>
                            <button type="button" class="btn btn-sm btn-outline-primary" id="addLotRow">
                                <i class="fas fa-plus me-1"></i>Ajouter un lot
                            </button>
                        </div>
                        
                        <div class="table-responsive">
                            <table class="table table-hover" id="lotsTable">
                                <thead class="table-light">
                                    <tr>
                                        <th>Numéro</th>
                                        <th>Position</th>
                                        <th>Superficie (m²)</th>
                                        <th>Prix de base</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody id="lotsContainer">
                                    <!-- Les lignes seront ajoutées ici par JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="{{ route('sites.lots.index', $site) }}" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-1"></i> Retour
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i> Enregistrer les lots
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Template pour une nouvelle ligne de lot -->
    <template id="lotRowTemplate">
        <tr class="lot-row">
            <td>
                <input type="text" name="lots[INDEX][lot_number]" class="form-control lot-number" required>
            </td>
            <td>
                <select name="lots[INDEX][position]" class="form-select position-select">
                    <option value="interieur">Intérieur</option>
                    <option value="facade">Façade (+10%)</option>
                    <option value="angle">Angle (+10%)</option>
                </select>
            </td>
            <td>
                <input type="number" step="0.01" name="lots[INDEX][area]" class="form-control area" required>
            </td>
            <td>
                <input type="number" step="0.01" name="lots[INDEX][base_price]" class="form-control base-price" readonly>
            </td>
            <td>
                <button type="button" class="btn btn-sm btn-outline-danger remove-lot">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    </template>

    @push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const container = document.getElementById('lotsContainer');
            const addButton = document.getElementById('addLotRow');
            const template = document.getElementById('lotRowTemplate');
            const defaultPosition = document.getElementById('defaultPosition');
            const defaultArea = document.getElementById('defaultArea');
            const pricePerSqm = document.getElementById('pricePerSqm');
            let lotIndex = 0;

            // Ajouter un nouveau lot
            function addLotRow() {
                const newRow = document.importNode(template.content, true);
                const rowHtml = newRow.querySelector('tr').outerHTML.replace(/INDEX/g, lotIndex);
                container.insertAdjacentHTML('beforeend', rowHtml);
                
                // Mettre à jour les valeurs par défaut
                const row = container.lastElementChild;
                const positionSelect = row.querySelector('.position-select');
                const areaInput = row.querySelector('.area');
                const basePriceInput = row.querySelector('.base-price');
                
                // Définir les valeurs par défaut
                positionSelect.value = defaultPosition.value;
                areaInput.value = defaultArea.value;
                
                // Calculer le prix de base
                updateBasePrice(areaInput, basePriceInput, positionSelect);
                
                lotIndex++;
                
                return row;
            }
            
            // Mettre à jour le prix de base
            function updateBasePrice(areaInput, basePriceInput, positionSelect) {
                const area = parseFloat(areaInput.value) || 0;
                const price = parseFloat(pricePerSqm.value) || 0;
                let multiplier = 1;
                
                // Appliquer le multiplicateur selon la position
                if (positionSelect.value === 'facade' || positionSelect.value === 'angle') {
                    multiplier = 1.1; // +10% pour les lots en façade ou angle
                }
                
                const basePrice = (area * price * multiplier).toFixed(2);
                basePriceInput.value = basePrice;
            }
            
            // Gérer les événements
            addButton.addEventListener('click', addLotRow);
            
            // Supprimer une ligne
            container.addEventListener('click', function(e) {
                if (e.target.closest('.remove-lot')) {
                    const row = e.target.closest('tr');
                    if (container.children.length > 1) {
                        row.remove();
                    } else {
                        // Réinitialiser la dernière ligne au lieu de la supprimer
                        const inputs = row.querySelectorAll('input');
                        inputs.forEach(input => input.value = '');
                        row.querySelector('.position-select').value = defaultPosition.value;
                    }
                }
            });
            
            // Mettre à jour les prix quand la superficie ou le prix au m² change
            document.addEventListener('input', function(e) {
                if (e.target.matches('.area, #pricePerSqm') || e.target.matches('.position-select')) {
                    const row = e.target.closest('tr');
                    if (row) {
                        const areaInput = row.querySelector('.area');
                        const basePriceInput = row.querySelector('.base-price');
                        const positionSelect = row.querySelector('.position-select');
                        updateBasePrice(areaInput, basePriceInput, positionSelect);
                    }
                }
            });
            
            // Mettre à jour la position par défaut des nouvelles lignes
            defaultPosition.addEventListener('change', function() {
                document.querySelectorAll('.position-select').forEach(select => {
                    if (select.value === defaultPosition.value) return;
                    select.value = defaultPosition.value;
                    const event = new Event('change');
                    select.dispatchEvent(event);
                });
            });
            
            // Ajouter une ligne vide au chargement
            addLotRow();
        });
    </script>
    @endpush
</x-app-layout>
