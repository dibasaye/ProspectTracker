<x-app-layout>
    <x-slot name="header">
        <h2 class="h4 fw-bold"><i class="fas fa-plus me-2"></i>Créer un Site</h2>
    </x-slot>

    <div class="container py-4">
        <form action="{{ route('sites.store') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <!-- Infos générales -->
            <div class="mb-3">
                <label class="form-label">Nom du site</label>
                <input type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required>
                @error('name')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label class="form-label">Localisation</label>
                <input type="text" class="form-control @error('location') is-invalid @enderror" name="location" value="{{ old('location') }}" required>
                @error('location')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea class="form-control @error('description') is-invalid @enderror" name="description" rows="3">{{ old('description') }}</textarea>
                @error('description')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Superficie Totale</label>
                    <input type="number" step="0.01" class="form-control @error('total_area') is-invalid @enderror" name="total_area" value="{{ old('total_area') }}" required>
                    @error('total_area')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <div class="col-md-4">
                    <label class="form-label">Prix au mètre carré (FCFA/m²)</label>
                    <input type="number" step="0.01" class="form-control @error('price_per_sqm') is-invalid @enderror" name="price_per_sqm" value="{{ old('price_per_sqm') }}" required>
                    @error('price_per_sqm')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <div class="col-md-4">
                    <label class="form-label">Prix des lots en angle (FCFA)</label>
                    <input type="number" class="form-control @error('angle_price') is-invalid @enderror" name="angle_price" value="{{ old('angle_price') }}" required>
                    @error('angle_price')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <div class="col-md-4">
                    <label class="form-label">Prix des lots en façade (FCFA)</label>
                    <input type="number" class="form-control @error('facade_price') is-invalid @enderror" name="facade_price" value="{{ old('facade_price') }}" required>
                    @error('facade_price')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <div class="col-md-4">
                    <label class="form-label">Prix des lots intérieurs (FCFA)</label>
                    <input type="number" class="form-control @error('interior_price') is-invalid @enderror" name="interior_price" value="{{ old('interior_price') }}" required>
                    @error('interior_price')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <div class="col-md-6">
                    <label class="form-label">Frais de réservation (FCFA)</label>
                    <input type="number" class="form-control @error('reservation_fee') is-invalid @enderror" name="reservation_fee" value="{{ old('reservation_fee') }}" required>
                    @error('reservation_fee')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>

            <div class="row g-3 mt-3">
                <div class="col-md-4">
                    <label class="form-label">Frais d'adhésion (FCFA)</label>
                    <input type="number" class="form-control @error('membership_fee') is-invalid @enderror" name="membership_fee" value="{{ old('membership_fee') }}" required>
                    @error('membership_fee')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <div class="col-md-4">
                    <label class="form-label">Nombre total de lots</label>
                    <input type="number" class="form-control @error('total_lots') is-invalid @enderror" name="total_lots" value="{{ old('total_lots') }}" required>
                    @error('total_lots')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <div class="col-md-4">
                    <label class="form-label">Date de lancement</label>
                    <input type="date" class="form-control @error('launch_date') is-invalid @enderror" name="launch_date" value="{{ old('launch_date') }}">
                    @error('launch_date')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>

            <div class="row g-3 mt-3">
                <div class="col-md-6">
                    <label class="form-label">Latitude</label>
                    <input type="text" class="form-control @error('latitude') is-invalid @enderror" name="latitude" value="{{ old('latitude') }}" placeholder="Ex : 14.6928">
                    @error('latitude')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <div class="col-md-6">
                    <label class="form-label">Longitude</label>
                    <input type="text" class="form-control @error('longitude') is-invalid @enderror" name="longitude" value="{{ old('longitude') }}" placeholder="Ex : -17.4467">
                    @error('longitude')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>

            <div class="row g-3 mt-3">
                <div class="col-md-6">
                    <label class="form-label">Plan de lotissement (PDF/Image, max 2MB)</label>
                    <input type="file" class="form-control @error('image_file') is-invalid @enderror" name="image_file" accept=".pdf,image/*">
                    @error('image_file')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                    <small class="form-text text-muted">Formats acceptés : JPG, PNG, PDF (max 2MB)</small>
                </div>
            </div>

            <!-- Plan de paiement avec options à cocher -->
            <!-- Options de paiement -->
            <div class="mt-4 p-3 border rounded bg-light">
                <h5 class="mb-3">Options de paiement</h5>
                
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Prix pour paiement 1 an (FCFA)</label>
                        <input type="number" class="form-control @error('one_year_price') is-invalid @enderror" 
                               name="one_year_price" value="{{ old('one_year_price') }}">
                        @error('one_year_price')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Prix pour paiement 2 ans (FCFA)</label>
                        <input type="number" class="form-control @error('two_years_price') is-invalid @enderror" 
                               name="two_years_price" value="{{ old('two_years_price') }}">
                        @error('two_years_price')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Prix pour paiement 3 ans (FCFA)</label>
                        <input type="number" class="form-control @error('three_years_price') is-invalid @enderror" 
                               name="three_years_price" value="{{ old('three_years_price') }}">
                        @error('three_years_price')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                <div class="mb-3 d-none @error('price_cash') is-invalid @enderror" id="priceCash">
                    <label class="form-label">Prix total (Paiement cash)</label>
                    <input type="number" class="form-control @error('price_cash') is-invalid @enderror" name="price_cash" value="{{ old('price_cash') }}" placeholder="Ex : 4500000">
                    @error('price_cash')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>

            <div class="mt-4">
                <button class="btn btn-primary">✅ Enregistrer</button>
                <a href="{{ route('sites.index') }}" class="btn btn-secondary">❌ Annuler</a>
            </div>
        </form>
    </div>

    <!-- Script pour afficher/masquer les champs prix -->
    <script>
        document.querySelectorAll('.toggle-price').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const target = document.querySelector(this.dataset.target);
                if (this.checked) {
                    target.classList.remove('d-none');
                } else {
                    target.classList.add('d-none');
                    target.querySelector('input').value = ''; // réinitialiser si décoché
                }
            });
        });
    </script>
</x-app-layout>
