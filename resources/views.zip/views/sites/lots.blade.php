<x-app-layout>
    <x-slot name="header">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="h4 fw-bold">
                    <i class="fas fa-th me-2"></i>Lots - {{ $site->name }}
                </h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="{{ route('sites.index') }}">Sites</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('sites.show', $site) }}">{{ $site->name }}</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Lots</li>
                    </ol>
                </nav>
            </div>
            @if(auth()->user()->isAdmin() || auth()->user()->isManager())
                <div class="btn-group" role="group">
                    <a href="{{ route('sites.lots.create', $site) }}" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Nouveau Lot
                    </a>
                    <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="visually-hidden">Menu déroulant</span>
                    </button>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item" href="{{ route('sites.lots.add-manually', $site) }}">
                                <i class="fas fa-list-ol me-2"></i>Ajouter plusieurs lots
                            </a>
                        </li>
                    </ul>
                </div>
            @endif
        </div>
    </x-slot>

    <!-- Section Réservation Rapide -->
    @if(auth()->check() && (auth()->user()->isAgent() || auth()->user()->isAdmin()))
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-bolt me-2"></i>Réservation Rapide
                </h5>
                <button type="button" class="btn btn-sm btn-light" id="toggleReservationForm">
                    <i class="fas fa-chevron-down"></i>
                </button>
            </div>
            <div class="card-body" id="reservationFormContainer">
                <!-- Onglets -->
                <ul class="nav nav-tabs mb-3" id="reservationTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="single-tab" data-bs-toggle="tab" data-bs-target="#single-reservation" type="button" role="tab">
                            Réservation simple
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="multiple-tab" data-bs-toggle="tab" data-bs-target="#multiple-reservation" type="button" role="tab">
                            Réservation multiple
                        </button>
                    </li>
                </ul>
                
                <!-- Contenu des onglets -->
                <div class="tab-content" id="reservationTabsContent">
                    <!-- Réservation simple -->
                    <div class="tab-pane fade show active" id="single-reservation" role="tabpanel" aria-labelledby="single-tab">
            <div class="card-body">
                <form action="{{ route('sites.lots.reserve-by-number', $site) }}" method="POST" id="quickReserveForm">
                    @csrf
                    <div class="row g-3">
                        <div class="col-md-2">
                            <label for="lot_number" class="form-label fw-bold">Numéro de Lot</label>
                            <input type="text" class="form-control" id="lot_number" name="lot_number" required 
                                   placeholder="Ex: A1, B2..." maxlength="10">
                        </div>
                        
                        <div class="col-md-2">
                            <label for="client_id" class="form-label fw-bold">Client</label>
                            <select class="form-select" id="client_id" name="client_id" required>
                                <option value="">Choisir un client...</option>
                                @foreach($prospects as $prospect)
                                    <option value="{{ $prospect->id }}">
                                        {{ $prospect->first_name }} {{ $prospect->last_name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        
                        <div class="col-md-2">
                            <label for="area" class="form-label fw-bold">Surface (m²)</label>
                            <input type="number" class="form-control" id="area" name="area" required 
                                   min="0" step="0.01" placeholder="Ex: 150">
                        </div>
                        
                        <div class="col-md-2">
                            <label for="base_price" class="form-label fw-bold">Prix de Base</label>
                            <input type="number" class="form-control" id="base_price" name="base_price" required 
                                   min="0" placeholder="Ex: 5000000">
                        </div>
                        
                        <div class="col-md-2">
                            <label for="position" class="form-label fw-bold">Position</label>
                            <select class="form-select" id="position" name="position" required>
                                <option value="">Choisir...</option>
                                <option value="interieur">Intérieur</option>
                                <option value="facade">Façade</option>
                                <option value="angle">Angle</option>
                            </select>
                        </div>
                        
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-success w-100">
                                <i class="fas fa-check me-1"></i>Réserver
                            </button>
                        </div>
                    </div>
                    
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <label for="description" class="form-label">Description (optionnel)</label>
                            <textarea class="form-control" id="description" name="description" rows="2" 
                                      placeholder="Description du lot..."></textarea>
                        </div>
                        <div class="col-md-6 d-flex align-items-end">
                            <div class="alert alert-info mb-0 w-100">
                                <small>
                                    <i class="fas fa-info-circle me-1"></i>
                                    <strong>Info :</strong> Si le lot existe déjà et est disponible, il sera réservé. 
                                    Sinon, un nouveau lot sera créé et réservé automatiquement.
                                </small>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    @endif -->

    <div class="row mb-4">
        <!-- FILTRES -->
        <div class="col-md-3 mb-3">
            <label for="statusFilter" class="form-label fw-bold">Filtrer par statut</label>
            <select id="statusFilter" class="form-select" aria-label="Filtrer par statut">
                <option value="">Tous</option>
                <option value="disponible">Disponible</option>
                <option value="reserve">Réservé</option>
                <option value="vendu">Vendu</option>
            </select>
        </div>

        <div class="col-md-3 mb-3">
            <label for="positionFilter" class="form-label fw-bold">Filtrer par position</label>
            <select id="positionFilter" class="form-select" aria-label="Filtrer par position">
                <option value="">Toutes</option>
                <option value="angle">Angle</option>
                <option value="facade">Façade</option>
                <option value="interieur">Intérieur</option>
            </select>
        </div>

        <div class="col-md-4 mb-3">
            <label for="searchLot" class="form-label fw-bold">Rechercher un lot</label>
            <input type="search" id="searchLot" class="form-control" placeholder="Par numéro de lot...">
        </div>

        <div class="col-md-2 d-flex align-items-end mb-3">
            <button id="clearFilters" class="btn btn-secondary w-100">Réinitialiser</button>
        </div>
    </div>

    @if($lots->count())
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                @if(auth()->check() && (auth()->user()->isAdmin() || auth()->user()->isAgent()))
                <div class="mb-3 d-flex align-items-center">
                    <div class="form-check me-3">
                        <input class="form-check-input" type="checkbox" id="selectAllLots">
                        <label class="form-check-label fw-bold" for="selectAllLots">
                            Tout sélectionner
                        </label>
                    </div>
                    <button type="button" class="btn btn-primary btn-sm" id="reserveMultipleBtn" disabled>
                        <i class="fas fa-save me-1"></i>Réserver les lots sélectionnés
                    </button>
                </div>
                @endif
                <div class="row g-3" id="lotsGrid">
                    @foreach($lots as $lot)
                        <div class="col-xl-2 col-lg-3 col-md-4 col-6 lot-item" 
                             data-status="{{ $lot->status }}" 
                             data-position="{{ $lot->position }}" 
                             data-number="{{ strtolower($lot->lot_number) }}">
                            <div class="card h-100 lot-card position-relative" style="border: 2px solid {{ $lot->status_color }} !important;">
                                @if($lot->status === 'disponible' && (auth()->user()->isAdmin() || auth()->user()->isAgent()))
                                <div class="position-absolute top-0 start-0 p-2">
                                    <input type="checkbox" class="form-check-input lot-checkbox" 
                                           value="{{ $lot->id }}" 
                                           data-lot-number="{{ $lot->lot_number }}" 
                                           data-price="{{ $lot->final_price }}">
                                </div>
                                @endif
                                <div class="card-body p-3 text-center">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h6 class="mb-0">{{ $lot->lot_number }}</h6>
                                        @if($lot->position === 'angle')
                                            <i class="fas fa-crown text-warning" title="Lot en angle"></i>
                                        @elseif($lot->position === 'facade')
                                            <i class="fas fa-star text-info" title="Lot en façade"></i>
                                        @endif
                                    </div>

                                    <div class="mb-2">
                                        <small class="text-muted">{{ $lot->area }} m²</small>
                                    </div>

                                    <div class="mb-2">
                                        <div class="fw-bold text-primary">{{ number_format($lot->final_price, 0, ',', ' ') }} FCFA</div>
                                        @if($lot->position !== 'interieur')
                                            <small class="text-muted">(Base : {{ number_format($lot->base_price, 0, ',', ' ') }} FCFA)</small>
                                        @endif
                                    </div>

                                    <div class="mb-2">
                                        <span class="badge w-100" style="background-color: {{ $lot->status_color }}; color: white;">
                                            {{ $lot->status_label }}
                                        </span>
                                    </div>

                                    @if($lot->reserved_until && $lot->status === 'reserve_temporaire')
                                        <div class="mb-2">
                                            <small class="text-warning">
                                                <i class="fas fa-clock me-1"></i>
                                                Expire : {{ $lot->reserved_until->format('d/m H:i') }}
                                            </small>
                                        </div>
                                    @endif

                                  {{-- Affichage du client (vente ou réservation) --}}
@php
    $contract = $lot->contracts->first();
    $client = $contract ? $contract->client : null;
    $reservation = $lot->reservation;
    $prospect = $reservation ? $reservation->prospect : null;
    
    $clientName = null;
    if ($client) {
        $clientName = trim($client->first_name . ' ' . $client->last_name);
    } elseif ($prospect) {
        $clientName = trim($prospect->first_name . ' ' . $prospect->last_name);
    }
@endphp

@if($contract)
    <div class="mb-2">
        <small class="text-muted">
            <i class="fas fa-user me-1"></i>Vendu à {{ $clientName ?? 'Client inconnu' }}
        </small>
    </div>
@elseif($reservation && $prospect)
    <div class="mb-2">
        <small class="text-muted">
            <i class="fas fa-user me-1"></i>
            Réservé par {{ $clientName ?? 'Client inconnu' }}
        </small>
        @if($reservation->expires_at)
            <br>
            <small class="text-warning">
                <i class="fas fa-clock me-1"></i>
                Expire le {{ $reservation->expires_at->format('d/m/Y H:i') }}
            </small>
        @endif
    </div>
@endif

                                    <div class="d-grid gap-1">
                                        {{-- Bouton Éditer (admin ou manager) --}}
                                        @if(auth()->check() && (auth()->user()->isAdmin() || auth()->user()->isManager()))
                                            <a href="{{ route('sites.lots.edit', ['site' => $site->id, 'lot' => $lot->id]) }}" 
                                               class="btn btn-sm btn-info text-white mb-1"
                                               title="Modifier le lot">
                                                <i class="fas fa-edit me-1"></i>Modifier
                                            </a>
                                        @endif

                                        {{-- Bouton Réserver (uniquement pour agents et admin) --}}
                                        @if(auth()->check() && (auth()->user()->isAgent() || auth()->user()->isAdmin()))
                                            @if($lot->status === 'disponible')
                                                <button class="btn btn-sm btn-success reserve-lot-btn mb-1" 
                                                        data-lot-id="{{ $lot->id }}" 
                                                        data-site-id="{{ $site->id }}"
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#reserveLotModal">
                                                    <i class="fas fa-lock me-1"></i>Réserver
                                                </button>
                                            @endif
                                        @endif

                                        {{-- Bouton Libérer (admin ou manager) --}}
                                        @if(auth()->check() && (auth()->user()->isAdmin() || auth()->user()->isManager()))
                                            @if($lot->status === 'reserve')
                                                <button class="btn btn-sm btn-warning release-lot-btn" 
                                                        data-lot-id="{{ $lot->id }}" 
                                                        data-site-id="{{ $site->id }}">
                                                    <i class="fas fa-unlock me-1"></i>Libérer
                                                </button>
                                            @endif
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <button type="button" class="btn btn-primary me-2" id="reserveMultipleBtn" disabled>
                        <i class="fas fa-save me-2"></i>Réserver
                    </button>
                    <span class="text-muted">
                        Affichage de {{ $lots->firstItem() }} à {{ $lots->lastItem() }} sur {{ $lots->total() }} lots
                    </span>
                </div>
                {{ $lots->links() }}
            </div>
        </div>
    @else
        <div class="text-center py-5">
            <i class="fas fa-home fa-3x text-muted mb-3"></i>
            <h5 class="text-muted">Aucun lot créé</h5>
            <p class="text-muted">Commencez par créer les lots de ce site</p>
            @if(auth()->user()->isAdmin() || auth()->user()->isManager())
                <a href="{{ route('sites.lots.create', $site) }}" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Créer un lot
                </a>
            @endif
        </div>
    @endif

    {{-- Modal Réserver --}}
    @if(auth()->check() && (auth()->user()->isAgent() || auth()->user()->isAdmin()))
        <div class="modal fade" id="reserveLotModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <form id="reserveLotForm" method="POST" action="">
                    @csrf
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Réserver un Lot</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                        </div>
                        <div class="modal-body">
                            <label for="prospectSelect" class="form-label">Sélectionnez un prospect :</label>
                            <select id="prospectSelect" name="client_id" class="form-select" required>
                                <option value="">Choisir un prospect...</option>
                                @foreach($prospects as $prospect)
                                    <option value="{{ $prospect->id }}">
                                        {{ $prospect->first_name }} {{ $prospect->last_name }} - {{ $prospect->phone }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                            <button type="submit" class="btn btn-primary">Réserver</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    @endif

    <!-- Modal de réservation multiple -->
    <div class="modal fade" id="reserveMultipleModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">
                        <i class="fas fa-tasks me-2"></i>Réserver plusieurs lots
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                </div>
                <form action="{{ route('sites.lots.reserve-multiple', $site) }}" method="POST" id="reserveMultipleForm">
                    @csrf
                    <input type="hidden" name="lot_ids" id="selected_lot_ids">
                    <div class="modal-body">
                        <div class="mb-4">
                            <h6>Lots sélectionnés :</h6>
                            <div id="selectedLotsList" class="mb-3 p-2 bg-light rounded">
                                <!-- La liste des lots sélectionnés sera ajoutée ici par JavaScript -->
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="client_id" class="form-label fw-bold">Client</label>
                            <select name="client_id" id="client_id" class="form-select" required>
                                <option value="">Sélectionner un client</option>
                                @foreach($prospects as $prospect)
                                    <option value="{{ $prospect->id }}">
                                        {{ $prospect->full_name }} ({{ $prospect->phone }})
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Options de paiement</label>
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="radio" name="payment_option" 
                                       id="one_year" value="one_year" required>
                                <label class="form-check-label" for="one_year">
                                    Paiement en 1 an ({{ $site->one_year_price ?? 0 }}% de majoration)
                                </label>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="radio" name="payment_option" 
                                       id="two_years" value="two_years">
                                <label class="form-check-label" for="two_years">
                                    Paiement en 2 ans ({{ $site->two_years_price ?? 0 }}% de majoration)
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="payment_option" 
                                       id="three_years" value="three_years">
                                <label class="form-check-label" for="three_years">
                                    Paiement en 3 ans ({{ $site->three_years_price ?? 0 }}% de majoration)
                                </label>
                            </div>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            Le montant total sera calculé automatiquement après la sélection des lots.
                        </div>
                        
                        <div class="d-flex justify-content-end align-items-center mt-3">
                            <h5 class="mb-0 me-3">Total : <span id="totalAmount" class="text-primary">0 FCFA</span></h5>
                            <input type="hidden" name="total_amount" id="total_amount" value="0">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="fas fa-times me-2"></i>Annuler
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Confirmer la réservation
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @push('scripts')
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Éléments de sélection multiple
                const selectAllCheckbox = document.getElementById('selectAllLots');
                let lotCheckboxes = document.querySelectorAll('.lot-checkbox');
                const reserveMultipleBtn = document.getElementById('reserveMultipleBtn');
                const reserveMultipleModal = document.getElementById('reserveMultipleModal');
                const selectedLotsList = document.getElementById('selectedLotsList');
                const selectedLotIds = document.getElementById('selected_lot_ids');
                
                // Fonction pour mettre à jour l'état du bouton de réservation
                function toggleReserveButton() {
                    const selectedLots = document.querySelectorAll('.lot-checkbox:checked');
                    if (reserveMultipleBtn) {
                        reserveMultipleBtn.disabled = selectedLots.length === 0;
                        if (selectedLots.length > 0) {
                            reserveMultipleBtn.innerHTML = `<i class="fas fa-save me-1"></i>Réserver (${selectedLots.length} lots)`;
                        } else {
                            reserveMultipleBtn.innerHTML = '<i class="fas fa-save me-1"></i>Réserver';
                        }
                    }
                }
                
                // Fonction pour mettre à jour la liste des lots sélectionnés
                function updateSelectedLotsList() {
                    const selectedLots = document.querySelectorAll('.lot-checkbox:checked');
                    const lotIds = [];
                    let html = '<div class="list-group">';
                    
                    selectedLots.forEach(checkbox => {
                        const lotNumber = checkbox.dataset.lotNumber;
                        const price = parseFloat(checkbox.dataset.price).toLocaleString('fr-FR');
                        lotIds.push(checkbox.value);
                        
                        html += `
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <span>Lot ${lotNumber}</span>
                                <span class="badge bg-primary rounded-pill">${price} FCFA</span>
                            </div>
                        `;
                    });
                    
                    html += '</div>';
                    
                    if (selectedLotsList) {
                        selectedLotsList.innerHTML = selectedLots.length > 0 ? html : '<div class="text-muted">Aucun lot sélectionné</div>';
                    }
                    
                    if (selectedLotIds) {
                        selectedLotIds.value = JSON.stringify(lotIds);
                    }
                    
                    updateTotalAmount();
                }
                
                // Calculer et mettre à jour le montant total
                function updateTotalAmount() {
                    const selectedLots = document.querySelectorAll('.lot-checkbox:checked');
                    let total = 0;
                    
                    selectedLots.forEach(checkbox => {
                        total += parseFloat(checkbox.dataset.price) || 0;
                    });
                    
                    const totalElement = document.getElementById('totalAmount');
                    if (totalElement) {
                        totalElement.textContent = total.toLocaleString('fr-FR') + ' FCFA';
                    }
                    
                    const totalInput = document.getElementById('total_amount');
                    if (totalInput) {
                        totalInput.value = total;
                    }
                }
                
                // Gérer le clic sur le bouton de réservation multiple
                if (reserveMultipleBtn) {
                    reserveMultipleBtn.addEventListener('click', function() {
                        const selectedLots = document.querySelectorAll('.lot-checkbox:checked');
                        if (selectedLots.length === 0) {
                            alert('Veuillez sélectionner au moins un lot à réserver.');
                            return;
                        }
                        
                        updateSelectedLotsList();
                        
                        const modal = new bootstrap.Modal(reserveMultipleModal);
                        modal.show();
                    });
                }
                
                // Gérer la sélection/désélection de tous les lots
                if (selectAllCheckbox) {
                    selectAllCheckbox.addEventListener('change', function() {
                        const isChecked = this.checked;
                        lotCheckboxes.forEach(checkbox => {
                            if (checkbox.disabled === false) {
                                checkbox.checked = isChecked;
                            }
                        });
                        updateSelectedLotsList();
                        toggleReserveButton();
                    });
                }
                
                // Mettre à jour l'état de la case "Tout sélectionner"
                function updateSelectAllCheckbox() {
                    if (!selectAllCheckbox) return;
                    
                    const checkboxes = Array.from(lotCheckboxes);
                    const allChecked = checkboxes.length > 0 && 
                                     checkboxes.every(checkbox => checkbox.checked || checkbox.disabled);
                    selectAllCheckbox.checked = allChecked;
                }
                
                // Initialiser les écouteurs d'événements pour les cases à cocher
                function initCheckboxListeners() {
                    lotCheckboxes = document.querySelectorAll('.lot-checkbox');
                    
                    lotCheckboxes.forEach(checkbox => {
                        checkbox.addEventListener('change', function() {
                            // Décocher "Tout sélectionner" si une case est décochée
                            if (selectAllCheckbox && !this.checked) {
                                selectAllCheckbox.checked = false;
                            }
                            updateSelectAllCheckbox();
                            updateSelectedLotsList();
                            toggleReserveButton();
                        });
                    });
                }
                
                // Initialiser
                initCheckboxListeners();
                toggleReserveButton();
                updateSelectedLotsList();
                
                // Mettre à jour le total lorsque l'option de paiement change
                const paymentOptions = document.querySelectorAll('input[name="payment_option"]');
                paymentOptions.forEach(option => {
                    option.addEventListener('change', updateTotalAmount);
                });
                
                // Fonction pour confirmer la réservation multiple
                window.confirmMultipleReservation = function() {
                    const selectedLots = document.querySelectorAll('.lot-checkbox:checked');
                    if (selectedLots.length === 0) {
                        alert('Veuillez sélectionner au moins un lot à réserver.');
                        return false;
                    }
                    
                    const clientId = document.getElementById('client_id').value;
                    
                    if (!clientId) {
                        alert('Veuillez sélectionner un client.');
                        return false;
                    }
                    
                    // Soumettre le formulaire
                    document.getElementById('reserveMultipleForm').submit();
                    return true;
                };
                
                // Gestion des filtres
                const statusFilter = document.getElementById('statusFilter');
                const positionFilter = document.getElementById('positionFilter');
                const searchLot = document.getElementById('searchLot');
                const clearFilters = document.getElementById('clearFilters');
                const lotItems = document.querySelectorAll('.lot-item');

                function filterLots() {
                    const statusValue = statusFilter ? statusFilter.value : '';
                    const positionValue = positionFilter ? positionFilter.value : '';
                    const searchValue = searchLot ? searchLot.value.trim().toLowerCase() : '';

                    lotItems.forEach(item => {
                        const status = item.dataset.status || '';
                        const position = item.dataset.position || '';
                        const number = item.dataset.number ? item.dataset.number.toLowerCase() : '';
                        const searchMatch = searchValue === '' || 
                                         (number && number.includes(searchValue));
                        
                        const statusMatch = !statusValue || status === statusValue;
                        const positionMatch = !positionValue || position === positionValue;

                        item.style.display = (statusMatch && positionMatch && searchMatch) ? 'block' : 'none';
                    });
                }

                if (statusFilter) statusFilter.addEventListener('change', filterLots);
                if (positionFilter) positionFilter.addEventListener('change', filterLots);
                if (searchLot) searchLot.addEventListener('input', filterLots);
                if (clearFilters) {
                    clearFilters.addEventListener('click', () => {
                        if (statusFilter) statusFilter.value = '';
                        if (positionFilter) positionFilter.value = '';
                        if (searchLot) searchLot.value = '';
                        filterLots();
                    });
                }

                // Gestion du formulaire de réservation rapide
                @if(auth()->check() && (auth()->user()->isAgent() || auth()->user()->isAdmin()))
                    const quickReserveForm = document.getElementById('quickReserveForm');
                    const lotNumberInput = document.getElementById('lot_number');
                    const basePriceInput = document.getElementById('base_price');
                    const positionSelect = document.getElementById('position');

                    // Auto-calcul du prix final basé sur la position
                    function updateFinalPrice() {
                        if (!basePriceInput || !positionSelect) return;
                        
                        const basePrice = parseFloat(basePriceInput.value) || 0;
                        const position = positionSelect.value;
                        let finalPrice = basePrice;

                        if (position === 'facade' || position === 'angle') {
                            finalPrice = basePrice * 1.10; // +10% pour façade et angle
                        }

                        // Mettre à jour le champ de prix final si présent
                        const finalPriceInput = document.getElementById('final_price');
                        if (finalPriceInput) {
                            finalPriceInput.value = finalPrice.toFixed(2);
                        }
                    }

                    if (basePriceInput) basePriceInput.addEventListener('input', updateFinalPrice);
                    if (positionSelect) positionSelect.addEventListener('change', updateFinalPrice);

                    // Validation du formulaire
                    if (quickReserveForm) {
                        quickReserveForm.addEventListener('submit', function(e) {
                            const lotNumber = lotNumberInput ? lotNumberInput.value.trim() : '';
                            const clientId = document.getElementById('client_id') ? document.getElementById('client_id').value : '';
                            const area = document.getElementById('area') ? document.getElementById('area').value : '';
                            const basePrice = basePriceInput ? basePriceInput.value : '';
                            const position = positionSelect ? positionSelect.value : '';

                            if (!lotNumber || !clientId || !area || !basePrice || !position) {
                                e.preventDefault();
                                alert('Veuillez remplir tous les champs obligatoires.');
                                return false;
                            }

                            // Confirmation avant soumission
                            if (!confirm(`Êtes-vous sûr de vouloir réserver le lot ${lotNumber} ?`)) {
                                e.preventDefault();
                                return false;
                            }
                            return true;
                        });
                    }

                    // Focus automatique sur le numéro de lot
                    if (lotNumberInput) lotNumberInput.focus();
                @endif
                
                // Initialisation des tooltips Bootstrap
                const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                tooltipTriggerList.map(function (tooltipTriggerEl) {
                    return new bootstrap.Tooltip(tooltipTriggerEl);
                });
            });
            
            // Fonction pour confirmer la réservation multiple
            function confirmMultipleReservation() {
                const selectedLots = document.querySelectorAll('.lot-checkbox:checked');
                if (selectedLots.length === 0) {
                    alert('Veuillez sélectionner au moins un lot à réserver.');
                    return false;
                }
                
                const clientId = document.getElementById('client_id').value;
                
                if (!clientId) {
                    alert('Veuillez sélectionner un client.');
                    return false;
                }
                
                // Soumettre le formulaire
                document.getElementById('reserveMultipleForm').submit();
                return true;
            }
            document.addEventListener('DOMContentLoaded', function() {
                // Éléments filtres
                const statusFilter = document.getElementById('statusFilter');
                const positionFilter = document.getElementById('positionFilter');
                const searchLot = document.getElementById('searchLot');
                const clearFilters = document.getElementById('clearFilters');
                const lotItems = document.querySelectorAll('.lot-item');

                function filterLots() {
                    const statusValue = statusFilter.value;
                    const positionValue = positionFilter.value;
                    const searchValue = searchLot.value.toLowerCase();

                    lotItems.forEach(item => {
                        const status = item.dataset.status;
                        const position = item.dataset.position;
                        const number = item.dataset.number.toLowerCase();

                        const statusMatch = !statusValue || status === statusValue;
                        const positionMatch = !positionValue || position === positionValue;
                        const searchMatch = !searchValue || number.includes(searchValue);

                        item.style.display = (statusMatch && positionMatch && searchMatch) ? 'block' : 'none';
                    });
                }

                statusFilter.addEventListener('change', filterLots);
                positionFilter.addEventListener('change', filterLots);
                searchLot.addEventListener('input', filterLots);
                clearFilters.addEventListener('click', () => {
                    statusFilter.value = '';
                    positionFilter.value = '';
                    searchLot.value = '';
                    filterLots();
                });

                // Gérer bouton Réserver
                @if(auth()->check() && (auth()->user()->isAgent() || auth()->user()->isAdmin()))
                    const reserveLotBtns = document.querySelectorAll('.reserve-lot-btn');
                    const prospectSelect = document.getElementById('prospectSelect');
                    const reserveLotForm = document.getElementById('reserveLotForm');

                    reserveLotBtns.forEach(btn => {
                        btn.addEventListener('click', () => {
                            const lotId = btn.dataset.lotId;
                            const siteId = btn.dataset.siteId;
                            reserveLotForm.action = `/sites/${siteId}/lots/${lotId}/reserve`;
                        });
                    });
                @endif

                // Gérer bouton Libérer
                @if(auth()->check() && (auth()->user()->isAdmin() || auth()->user()->isManager()))
                    const releaseLotBtns = document.querySelectorAll('.release-lot-btn');
                    releaseLotBtns.forEach(btn => {
                        btn.addEventListener('click', () => {
                            if (confirm('Êtes-vous sûr de vouloir libérer ce lot ?')) {
                                const form = document.createElement('form');
                                form.method = 'POST';
                                const siteId = btn.dataset.siteId;
                                const lotId = btn.dataset.lotId;
                                form.action = `/sites/${siteId}/lots/${lotId}/release`;
                                form.innerHTML = `<input type="hidden" name="_token" value="{{ csrf_token() }}">`;
                                document.body.appendChild(form);
                                form.submit();
                            }
                        });
                    });
                @endif

                // Gérer le formulaire de réservation rapide
                @if(auth()->check() && (auth()->user()->isAgent() || auth()->user()->isAdmin()))
                    const quickReserveForm = document.getElementById('quickReserveForm');
                    const lotNumberInput = document.getElementById('lot_number');
                    const basePriceInput = document.getElementById('base_price');
                    const positionSelect = document.getElementById('position');

                    // Auto-calcul du prix final basé sur la position
                    function updateFinalPrice() {
                        const basePrice = parseFloat(basePriceInput.value) || 0;
                        const position = positionSelect.value;
                        let finalPrice = basePrice;

                        if (position === 'facade' || position === 'angle') {
                            finalPrice = basePrice * 1.10; // +10% pour façade et angle
                        }

                        // Afficher le prix calculé (optionnel)
                        const priceDisplay = document.getElementById('priceDisplay');
                        if (priceDisplay) {
                            priceDisplay.textContent = `Prix final estimé: ${finalPrice.toLocaleString()} FCFA`;
                        }
                    }

                    basePriceInput.addEventListener('input', updateFinalPrice);
                    positionSelect.addEventListener('change', updateFinalPrice);

                    // Validation du formulaire
                    quickReserveForm.addEventListener('submit', function(e) {
                        const lotNumber = lotNumberInput.value.trim();
                        const clientId = document.getElementById('client_id').value;
                        const area = document.getElementById('area').value;
                        const basePrice = basePriceInput.value;
                        const position = positionSelect.value;

                        if (!lotNumber || !clientId || !area || !basePrice || !position) {
                            e.preventDefault();
                            alert('Veuillez remplir tous les champs obligatoires.');
                            return;
                        }

                        // Confirmation avant soumission
                        if (!confirm(`Êtes-vous sûr de vouloir réserver le lot ${lotNumber} ?`)) {
                            e.preventDefault();
                        }
                    });

                    // Focus automatique sur le numéro de lot
                    lotNumberInput.focus();
                @endif
            });
        </script>
    @endpush

</x-app-layout>
