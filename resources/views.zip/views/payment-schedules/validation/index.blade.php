@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card border-start border-4 border-warning shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-muted small">Échéances en attente</div>
                            <div class="h3 mb-0">{{ $stats['total_pending'] ?? 0 }}</div>
                        </div>
                        <div class="text-warning">
                            <i class="fas fa-clock fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-start border-4 border-info shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-muted small">Montant total</div>
                            <div class="h4 mb-0">{{ number_format($stats['total_amount'] ?? 0, 0, ',', ' ') }} FCFA</div>
                        </div>
                        <div class="text-info">
                            <i class="fas fa-money-bill-wave fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-start border-4 border-primary shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-muted small">Contrats concernés</div>
                            <div class="h3 mb-0">{{ $stats['by_contract'] ?? 0 }}</div>
                        </div>
                        <div class="text-primary">
                            <i class="fas fa-file-contract fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-start border-4 border-success shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-muted small">Clients concernés</div>
                            <div class="h3 mb-0">{{ $stats['by_client'] ?? 0 }}</div>
                        </div>
                        <div class="text-success">
                            <i class="fas fa-users fa-2x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center bg-light">
                    <h5 class="mb-0">
                        @if(auth()->user()->isCaissier())
                            <i class="fas fa-cash-register me-2"></i>Échéances à valider - Caissier
                        @elseif(auth()->user()->isResponsableCommercial())
                            <i class="fas fa-user-tie me-2"></i>Échéances à valider - Responsable Commercial
                        @elseif(auth()->user()->isAdmin())
                            <i class="fas fa-user-shield me-2"></i>Échéances à valider - Administrateur
                        @endif
                    </h5>
                    <div>
                        <a href="{{ route('payment-schedules.validation.history') }}" class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-history me-1"></i> Historique
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    @if(session('success'))
                        <div class="alert alert-success">{{ session('success') }}</div>
                    @endif
                    @if(session('error'))
                        <div class="alert alert-danger">{{ session('error') }}</div>
                    @endif

                    @if($schedules->isEmpty())
                        <div class="alert alert-info">
                            Aucune échéance en attente de validation.
                        </div>
                    @else
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Client</th>
                                        <th>Contrat</th>
                                        <th>Montant</th>
                                        <th>Date d'échéance</th>
                                        <th>Jours de retard</th>
                                        <th>Statut</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($schedules as $schedule)
                                        <tr>
                                            <td>{{ $schedule->id }}</td>
                                            <td>
                                                {{ $schedule->contract->client->full_name ?? 'N/A' }}
                                            </td>
                                            <td>
                                                <a href="{{ route('contracts.show', $schedule->contract) }}" target="_blank">
                                                    Contrat #{{ $schedule->contract->id }}
                                                </a>
                                            </td>
                                            <td class="fw-bold">{{ number_format($schedule->amount, 0, ',', ' ') }} FCFA</td>
                                            <td>
                                                {{ $schedule->due_date->format('d/m/Y') }}
                                                @if($schedule->due_date->isPast() && !$schedule->is_paid)
                                                    <span class="badge bg-danger ms-2">En retard</span>
                                                @endif
                                            </td>
                                            <td>
                                                @if($schedule->due_date->isPast() && !$schedule->is_paid)
                                                    {{ $schedule->due_date->diffInDays(now()) }} j
                                                @else
                                                    - 
                                                @endif
                                            </td>
                                            <td>
                                                @if($schedule->validation_status === 'caissier_validated')
                                                    <span class="badge bg-info">
                                                        <i class="fas fa-user-check me-1"></i> Caissier
                                                    </span>
                                                @elseif($schedule->validation_status === 'responsable_validated')
                                                    <span class="badge bg-primary">
                                                        <i class="fas fa-user-tie me-1"></i> Responsable
                                                    </span>
                                                @elseif($schedule->validation_status === 'admin_validated')
                                                    <span class="badge bg-success">
                                                        <i class="fas fa-user-shield me-1"></i> Administrateur
                                                    </span>
                                                @else
                                                    <span class="badge bg-warning">
                                                        <i class="fas fa-clock me-1"></i> En attente
                                                    </span>
                                                @endif
                                                
                                                @if($schedule->caissier_validated && $schedule->caissierValidatedBy)
                                                    <div class="small text-muted mt-1">
                                                        <i class="fas fa-user-check text-info"></i> 
                                                        {{ $schedule->caissierValidatedBy->name }} - 
                                                        {{ $schedule->caissier_validated_at->format('d/m/Y H:i') }}
                                                    </div>
                                                @endif
                                                
                                                @if($schedule->responsable_validated && $schedule->responsableValidatedBy)
                                                    <div class="small text-muted mt-1">
                                                        <i class="fas fa-user-tie text-primary"></i> 
                                                        {{ $schedule->responsableValidatedBy->name }} - 
                                                        {{ $schedule->responsable_validated_at->format('d/m/Y H:i') }}
                                                    </div>
                                                @endif
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm" role="group">
                                                    <a href="{{ route('payment-schedules.validation.show', $schedule) }}" 
                                                       class="btn btn-primary"
                                                       title="Voir les détails">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    @if(auth()->user()->can('reject', $schedule))
                                                    <button type="button" 
                                                            class="btn btn-danger"
                                                            title="Rejeter le paiement"
                                                            onclick="initRejectModal({{ $schedule->id }})">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                    @endif
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@include('payment-schedules.validation._reject_modal')

@push('scripts')
<script>
    // Initialiser la modale de rejet avec l'ID de l'échéance
    function initRejectModal(scheduleId) {
        const form = document.getElementById('rejectPaymentForm');
        form.action = `/payment-schedules/validation/${scheduleId}/reject`;
        $('#rejectPaymentModal').modal('show');
    }
</script>
@endpush

@endsection
