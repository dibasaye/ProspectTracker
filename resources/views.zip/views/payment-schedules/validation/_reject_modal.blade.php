<!-- Modal de rejet de paiement -->
<div class="modal fade" id="rejectPaymentModal" tabindex="-1" role="dialog" aria-labelledby="rejectPaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form id="rejectPaymentForm" action="{{ route('payment-schedules.validation.reject', ['schedule' => $schedule->id]) }}" method="POST">
                @csrf
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="rejectPaymentModalLabel">Rejeter le paiement</h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Fermer">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="rejection_reason" class="font-weight-bold">Motif du rejet <span class="text-danger">*</span></label>
                        <textarea name="rejection_reason" id="rejection_reason" class="form-control @error('rejection_reason') is-invalid @enderror" rows="5" required>{{ old('rejection_reason') }}</textarea>
                        @error('rejection_reason')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i> Cette action est irréversible. Veuillez fournir une explication claire pour le rejet.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-times-circle"></i> Confirmer le rejet
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

@push('scripts')
<script>
    // Gestion de la soumission du formulaire avec confirmation
    document.getElementById('rejectPaymentForm').addEventListener('submit', function(e) {
        if (!confirm('Êtes-vous sûr de vouloir rejeter ce paiement ? Cette action est irréversible.')) {
            e.preventDefault();
            return false;
        }
        return true;
    });
</script>
@endpush
