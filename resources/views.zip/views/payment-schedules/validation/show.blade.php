@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        Validation d'échéance #{{ $schedule->id }}
                    </h5>
                    <a href="{{ route('payment-schedules.validation.index') }}" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-arrow-left"></i> Retour
                    </a>
                </div>

                <div class="card-body">
                    @if(session('success'))
                        <div class="alert alert-success">{{ session('success') }}</div>
                    @endif
                    @if(session('error'))
                        <div class="alert alert-danger">{{ session('error') }}</div>
                    @endif

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5>Informations du client</h5>
                            <p class="mb-1"><strong>Nom :</strong> {{ $schedule->contract->client->full_name ?? 'N/A' }}</p>
                            <p class="mb-1"><strong>Téléphone :</strong> {{ $schedule->contract->client->phone ?? 'N/A' }}</p>
                            <p class="mb-1"><strong>Email :</strong> {{ $schedule->contract->client->email ?? 'N/A' }}</p>
                        </div>
                        <div class="col-md-6">
                            <h5>Détails du contrat</h5>
                            <p class="mb-1"><strong>Contrat :</strong> 
                                <a href="{{ route('contracts.show', $schedule->contract) }}" target="_blank">
                                    Voir le contrat #{{ $schedule->contract->id }}
                                </a>
                            </p>
                            <p class="mb-1"><strong>Date de début :</strong> {{ $schedule->contract->start_date->format('d/m/Y') }}</p>
                            <p class="mb-1"><strong>Durée :</strong> {{ $schedule->contract->payment_duration_months }} mois</p>
                            <p class="mb-1"><strong>Montant total :</strong> {{ number_format($schedule->contract->total_amount, 0, ',', ' ') }} FCFA</p>
                        </div>
                    </div>

                    <div class="card mb-4">
                        <div class="card-header bg-light">
                            <h6 class="mb-0">Détails de l'échéance</h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <p><strong>Numéro d'échéance :</strong> {{ $schedule->installment_number }}</p>
                                    <p><strong>Montant :</strong> {{ number_format($schedule->amount, 0, ',', ' ') }} FCFA</p>
                                    <p><strong>Date d'échéance :</strong> {{ $schedule->due_date->format('d/m/Y') }}</p>
                                </div>
                                <div class="col-md-8">
                                    <div class="alert alert-info">
                                        <h6>État de la validation :</h6>
                                        <div class="d-flex justify-content-between mb-2">
                                            <span>Caissier : 
                                                @if($schedule->caissier_validated)
                                                    <span class="text-success">Validé le {{ $schedule->caissier_validated_at->format('d/m/Y H:i') }}</span>
                                                @else
                                                    <span class="text-warning">En attente</span>
                                                @endif
                                            </span>
                                            <span>Responsable : 
                                                @if($schedule->responsable_validated)
                                                    <span class="text-success">Validé le {{ $schedule->responsable_validated_at->format('d/m/Y H:i') }}</span>
                                                @else
                                                    <span class="text-warning">En attente</span>
                                                @endif
                                            </span>
                                            <span>Admin : 
                                                @if($schedule->admin_validated)
                                                    <span class="text-success">Validé le {{ $schedule->admin_validated_at->format('d/m/Y H:i') }}</span>
                                                @else
                                                    <span class="text-warning">En attente</span>
                                                @endif
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    @if(auth()->user()->isCaissier() && $schedule->canBeValidatedByCaissier())
                        <div class="card mb-4">
                            <div class="card-header bg-primary text-white">
                                <h6 class="mb-0">Validation par le caissier</h6>
                            </div>
                            <div class="card-body">
                                <form action="{{ route('payment-schedules.validation.validate', $schedule) }}" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    <div class="mb-3">
                                        <label for="caissier_amount_received" class="form-label">Montant reçu (FCFA) *</label>
                                        <input type="number" class="form-control" id="caissier_amount_received" 
                                               name="caissier_amount_received" required min="0" 
                                               value="{{ old('caissier_amount_received', $schedule->amount) }}">
                                        @error('caissier_amount_received')
                                            <div class="invalid-feedback d-block">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="mb-3">
                                        <label for="payment_proof" class="form-label">Justificatif de paiement *</label>
                                        <input type="file" class="form-control" id="payment_proof" name="payment_proof" required>
                                        <div class="form-text">Formats acceptés : JPG, PNG, PDF (max 2 Mo)</div>
                                        @error('payment_proof')
                                            <div class="invalid-feedback d-block">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="mb-3">
                                        <label for="caissier_notes" class="form-label">Notes (optionnel)</label>
                                        <textarea class="form-control" id="caissier_notes" name="caissier_notes" rows="3">{{ old('caissier_notes') }}</textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-check-circle"></i> Valider le paiement
                                    </button>
                                </form>
                            </div>
                        </div>
                    @elseif(auth()->user()->isResponsableCommercial() && $schedule->canBeValidatedByResponsable())
                        <div class="card mb-4">
                            <div class="card-header bg-primary text-white">
                                <h6 class="mb-0">Validation par le responsable commercial</h6>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <h6>Informations du caissier</h6>
                                    <p class="mb-1">Validé par : {{ $schedule->caissierValidatedBy->name ?? 'N/A' }}</p>
                                    <p class="mb-1">Montant reçu : {{ number_format($schedule->caissier_amount_received, 0, ',', ' ') }} FCFA</p>
                                    <p class="mb-1">Date : {{ $schedule->caissier_validated_at->format('d/m/Y H:i') ?? 'N/A' }}</p>
                                    @if($schedule->payment_proof_path)
                                        <a href="{{ route('payment-schedules.validation.download-proof', $schedule) }}" class="btn btn-sm btn-outline-primary mt-2">
                                            <i class="fas fa-download"></i> Télécharger le justificatif
                                        </a>
                                    @endif
                                </div>
                                <form action="{{ route('payment-schedules.validation.validate', $schedule) }}" method="POST">
                                    @csrf
                                    <div class="mb-3">
                                        <label for="responsable_notes" class="form-label">Commentaires (optionnel)</label>
                                        <textarea class="form-control" id="responsable_notes" name="responsable_notes" rows="3">{{ old('responsable_notes') }}</textarea>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal">
                                            <i class="fas fa-times-circle"></i> Rejeter
                                        </button>
                                        <button type="submit" class="btn btn-success">
                                            <i class="fas fa-check-circle"></i> Valider
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    @elseif(auth()->user()->isAdmin() && $schedule->canBeValidatedByAdmin())
                        <div class="card mb-4">
                            <div class="card-header bg-primary text-white">
                                <h6 class="mb-0">Validation finale par l'administrateur</h6>
                            </div>
                            <div class="card-body">
                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <h6>Informations du caissier</h6>
                                        <p class="mb-1">Validé par : {{ $schedule->caissierValidatedBy->name ?? 'N/A' }}</p>
                                        <p class="mb-1">Montant reçu : {{ number_format($schedule->caissier_amount_received, 0, ',', ' ') }} FCFA</p>
                                        <p class="mb-1">Date : {{ $schedule->caissier_validated_at->format('d/m/Y H:i') ?? 'N/A' }}</p>
                                        @if($schedule->payment_proof_path)
                                            <a href="{{ route('payment-schedules.validation.download-proof', $schedule) }}" class="btn btn-sm btn-outline-primary mt-2">
                                                <i class="fas fa-download"></i> Télécharger le justificatif
                                            </a>
                                        @endif
                                    </div>
                                    <div class="col-md-6">
                                        <h6>Validation du responsable</h6>
                                        <p class="mb-1">Validé par : {{ $schedule->responsableValidatedBy->name ?? 'N/A' }}</p>
                                        <p class="mb-1">Date : {{ $schedule->responsable_validated_at->format('d/m/Y H:i') ?? 'N/A' }}</p>
                                        @if($schedule->responsable_notes)
                                            <p class="mb-1"><strong>Commentaires :</strong></p>
                                            <p>{{ $schedule->responsable_notes }}</p>
                                        @endif
                                    </div>
                                </div>
                                <form action="{{ route('payment-schedules.validation.validate', $schedule) }}" method="POST">
                                    @csrf
                                    <div class="mb-3">
                                        <label for="admin_notes" class="form-label">Commentaires (optionnel)</label>
                                        <textarea class="form-control" id="admin_notes" name="admin_notes" rows="3">{{ old('admin_notes') }}</textarea>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal">
                                            <i class="fas fa-times-circle"></i> Rejeter
                                        </button>
                                        <button type="submit" class="btn btn-success">
                                            <i class="fas fa-check-circle"></i> Valider définitivement
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    @else
                        <div class="alert alert-info">
                            <h5>État de la validation</h5>
                            <p>Cette échéance est en attente de validation par :</p>
                            <ul>
                                @if(!$schedule->caissier_validated)
                                    <li>Caissier</li>
                                @elseif(!$schedule->responsable_validated)
                                    <li>Responsable commercial</li>
                                @elseif(!$schedule->admin_validated)
                                    <li>Administrateur</li>
                                @endif
                            </ul>
                        </div>
                    @endif

                    <!-- Historique des validations -->
                    <div class="card">
                        <div class="card-header bg-light">
                            <h6 class="mb-0">Historique des validations</h6>
                        </div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                @if($schedule->caissier_validated)
                                    <li class="list-group-item">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <strong>Caissier</strong><br>
                                                <small class="text-muted">
                                                    {{ $schedule->caissierValidatedBy->name ?? 'N/A' }} - 
                                                    {{ $schedule->caissier_validated_at->format('d/m/Y H:i') ?? 'N/A' }}
                                                </small>
                                            </div>
                                            <div class="text-end">
                                                <span class="badge bg-success">Validé</span><br>
                                                <small>Montant : {{ number_format($schedule->caissier_amount_received, 0, ',', ' ') }} FCFA</small>
                                            </div>
                                        </div>
                                        @if($schedule->caissier_notes)
                                            <div class="mt-2 p-2 bg-light rounded">
                                                <small class="text-muted">{{ $schedule->caissier_notes }}</small>
                                            </div>
                                        @endif
                                    </li>
                                @endif
                                
                                @if($schedule->responsable_validated)
                                    <li class="list-group-item">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <strong>Responsable commercial</strong><br>
                                                <small class="text-muted">
                                                    {{ $schedule->responsableValidatedBy->name ?? 'N/A' }} - 
                                                    {{ $schedule->responsable_validated_at->format('d/m/Y H:i') ?? 'N/A' }}
                                                </small>
                                            </div>
                                            <div class="text-end">
                                                <span class="badge bg-success">Validé</span>
                                            </div>
                                        </div>
                                        @if($schedule->responsable_notes)
                                            <div class="mt-2 p-2 bg-light rounded">
                                                <small class="text-muted">{{ $schedule->responsable_notes }}</small>
                                            </div>
                                        @endif
                                    </li>
                                @endif
                                
                                @if($schedule->admin_validated)
                                    <li class="list-group-item">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <strong>Administrateur</strong><br>
                                                <small class="text-muted">
                                                    {{ $schedule->adminValidatedBy->name ?? 'N/A' }} - 
                                                    {{ $schedule->admin_validated_at->format('d/m/Y H:i') ?? 'N/A' }}
                                                </small>
                                            </div>
                                            <div class="text-end">
                                                <span class="badge bg-success">Validé</span>
                                            </div>
                                        </div>
                                        @if($schedule->admin_notes)
                                            <div class="mt-2 p-2 bg-light rounded">
                                                <small class="text-muted">{{ $schedule->admin_notes }}</small>
                                            </div>
                                        @endif
                                    </li>
                                @endif
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal de rejet -->
<div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="rejectModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="rejectModalLabel">Rejeter l'échéance</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
            </div>
            <form action="{{ route('payment-schedules.validation.reject', $schedule) }}" method="POST">
                @csrf
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="rejection_reason" class="form-label">Motif du rejet *</label>
                        <textarea class="form-control" id="rejection_reason" name="rejection_reason" rows="3" required></textarea>
                        <div class="form-text">Veuillez indiquer la raison du rejet de cette échéance.</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-danger">Confirmer le rejet</button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection
