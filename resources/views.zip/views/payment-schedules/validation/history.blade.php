@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        Historique des validations d'échéances
                    </h5>
                    <div>
                        <a href="{{ route('payment-schedules.validation.index') }}" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-tasks"></i> Échéances en attente
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    @if(session('success'))
                        <div class="alert alert-success">{{ session('success') }}</div>
                    @endif

                    @if($schedules->isEmpty())
                        <div class="alert alert-info">
                            Aucun historique de validation trouvé.
                        </div>
                    @else
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Client</th>
                                        <th>Contrat</th>
                                        <th>Montant</th>
                                        <th>Date d'échéance</th>
                                        <th>Statut</th>
                                        <th>Dernière action</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($schedules as $schedule)
                                        <tr>
                                            <td>{{ $schedule->id }}</td>
                                            <td>
                                                {{ $schedule->contract->client->full_name ?? 'N/A' }}
                                            </td>
                                            <td>
                                                <a href="{{ route('contracts.show', $schedule->contract) }}" target="_blank">
                                                    Contrat #{{ $schedule->contract->id }}
                                                </a>
                                            </td>
                                            <td>{{ number_format($schedule->amount, 0, ',', ' ') }} FCFA</td>
                                            <td>{{ $schedule->due_date->format('d/m/Y') }}</td>
                                            <td>
                                                @if($schedule->validation_status === 'validated')
                                                    <span class="badge bg-success">Validé</span>
                                                @elseif($schedule->validation_status === 'rejected')
                                                    <span class="badge bg-danger">Rejeté</span>
                                                @elseif($schedule->validation_status === 'caissier_validated')
                                                    <span class="badge bg-info">Caissier</span>
                                                @elseif($schedule->validation_status === 'responsable_validated')
                                                    <span class="badge bg-primary">Responsable</span>
                                                @else
                                                    <span class="badge bg-warning">En attente</span>
                                                @endif
                                            </td>
                                            <td>
                                                @if($schedule->admin_validated)
                                                    <small>Validé par admin<br>{{ $schedule->admin_validated_at->format('d/m/Y H:i') }}</small>
                                                @elseif($schedule->responsable_validated)
                                                    <small>Validé par responsable<br>{{ $schedule->responsable_validated_at->format('d/m/Y H:i') }}</small>
                                                @elseif($schedule->caissier_validated)
                                                    <small>Validé par caissier<br>{{ $schedule->caissier_validated_at->format('d/m/Y H:i') }}</small>
                                                @else
                                                    <small>Créé le {{ $schedule->created_at->format('d/m/Y') }}</small>
                                                @endif
                                            </td>
                                            <td>
                                                <a href="{{ route('payment-schedules.validation.show', $schedule) }}" 
                                                   class="btn btn-sm btn-primary"
                                                   title="Voir les détails">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                @if($schedule->payment_proof_path)
                                                    <a href="{{ route('payment-schedules.validation.download-proof', $schedule) }}" 
                                                       class="btn btn-sm btn-outline-secondary"
                                                       title="Télécharger le justificatif">
                                                        <i class="fas fa-file-download"></i>
                                                    </a>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="mt-4">
                            {{ $schedules->links() }}
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
